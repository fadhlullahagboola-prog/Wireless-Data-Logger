# Recorded data

Add real captures here, for example `environment_24h.csv`. A sample-format file is included below; its values are **illustrative, not measured**. Do not upload credentials or private Wi-Fi information.
