# ESP32 Environmental Data Logger

**C++ · ESP32 · Environmental Sensing · microSD · Wi-Fi · Embedded Systems**

An ESP32-based environmental monitoring system written in C++ using the Arduino framework. The firmware acquires temperature and humidity measurements from a DHT11 sensor, records them to a microSD card as CSV, and provides a local Wi-Fi dashboard and JSON API. Configurable NTP timestamps, offline logging, and a deep-sleep operating mode are included.

## Features

| Component | Description |
|---|---|
| Sensor acquisition | DHT11 temperature and humidity readings over GPIO |
| Removable storage | Append-only CSV records on microSD |
| Web interface | ESP32-hosted dashboard at `/` |
| JSON telemetry | `GET /api/status` |
| Data export | `GET /download` |
| Timestamps | UTC time from NTP when available, plus uptime in milliseconds |
| Offline logging | Local acquisition and storage without Wi-Fi |
| Power management | Configurable deep-sleep acquisition mode |

## System architecture

```mermaid
flowchart LR
    D[DHT11] -->|GPIO| E[ESP32 / C++ firmware]
    E -->|SD interface| S[microSD / CSV]
    E -->|USB serial| U[Serial diagnostics]
    E -->|Wi-Fi| W[Dashboard and JSON API]
    N[NTP] -->|UTC time| E
```

## Hardware

- ESP32 development board with SunFounder extension board and microSD slot
- Bare four-pin DHT11 temperature and humidity sensor
- 10 kΩ pull-up resistor between DATA and 3.3 V
- microSD card, breadboard wiring, USB power

With the DHT11 grille facing forward and pins downward, the pin order is `VCC | DATA | NC | GND`. Connect DATA to GPIO 4, VCC to 3.3 V, and GND to ground. See [hardware documentation](docs/hardware.md) for the interface details.

## Setup

1. Install Arduino IDE, the Espressif ESP32 board package, Adafruit DHT sensor library, and Adafruit Unified Sensor.
2. Open `firmware/EnvironmentalLogger/EnvironmentalLogger.ino`.
3. Configure GPIO assignments and the board-specific SD interface in `config.h`.
4. For Wi-Fi, copy `secrets.example.h` to `secrets.h` and enter your network credentials. Keep `secrets.h` out of version control. For standalone logging, disable Wi-Fi in `config.h`.
5. Insert a FAT32-formatted microSD card, upload the sketch, and open Serial Monitor at 115200 baud.
6. Access the ESP32 IP address printed in Serial Monitor to view the dashboard. Use `/api/status` for JSON and `/download` for CSV export.

## Data format

```csv
timestamp_utc,uptime_ms,temperature_c,humidity_pct
2026-11-23T18:00:00Z,2000,24.0,42.0
2026-11-23T18:00:02Z,4000,24.0,43.0
```

The CSV above illustrates the file format. If NTP time is unavailable, `timestamp_utc` is empty; uptime resets when the device reboots.

## Operating modes

**Continuous acquisition:** The default 2-second sample interval provides periodic sensor readings, CSV storage, and HTTP telemetry while the device is active.

**Deep-sleep acquisition:** A configurable interval allows the ESP32 to wake, record a reading, and return to sleep. The HTTP dashboard is not available while the MCU sleeps.

## Repository structure

```text
firmware/EnvironmentalLogger/   Main sketch, settings, credentials template
docs/                           Hardware interface and engineering design notes
examples/                       CSV format example
assets/                         Project images and data visualizations
scripts/                        CSV structure checking tool
.github/workflows/              Automated CSV format check
```

## Engineering decisions

- A 2-second sampling interval accommodates the DHT11 update rate.
- Writing and closing records after acquisition prioritizes persistence over throughput.
- SD storage remains independent of the Wi-Fi connection.
- NTP provides human-readable timestamps when a network is available.
- Deep sleep trades continuous network availability for lower idle power.

See [design decisions](docs/design-decisions.md) for implementation details.

## License

MIT. See [LICENSE](LICENSE).


## PlatformIO project layout

- `src/main.cpp`: main firmware, sensor acquisition, CSV logging, HTTP routes and sleep mode
- `include/config.h`: configurable pins, intervals and features
- `include/secrets.example.h`: Wi-Fi credential template (copy to `include/secrets.h`)
- `platformio.ini`: reproducible ESP32 Arduino-framework build
- `hardware/wiring.md`: connections and logical architecture
- `hardware/schematic.mmd`: editable Mermaid wiring illustration
- `data/sample_log.csv`: illustrative CSV format
- `images/`: add real prototype and dashboard photos

Build with `pio run`; upload with `pio run -t upload`; view serial output with `pio device monitor`. Verify the SD interface pin mapping for your particular SunFounder extension board before flashing.
