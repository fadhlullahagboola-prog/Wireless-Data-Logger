#!/usr/bin/env python3
"""Check a logger CSV for structural errors and approximate uptime gaps."""
import csv
import sys
from pathlib import Path

REQUIRED = {"timestamp_utc", "uptime_ms", "temperature_c", "humidity_pct"}

def check(path):
    with Path(path).open(newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        if not reader.fieldnames or not REQUIRED.issubset(reader.fieldnames):
            raise ValueError(f"Expected columns: {sorted(REQUIRED)}")
        total = errors = gaps = 0
        previous = None
        for row in reader:
            total += 1
            try:
                uptime = int(row["uptime_ms"])
                temp = float(row["temperature_c"])
                humidity = float(row["humidity_pct"])
                if not (-40 <= temp <= 80 and 0 <= humidity <= 100):
                    raise ValueError("out-of-range value")
                if previous is not None and uptime >= previous and uptime - previous > 3000:
                    gaps += 1
                previous = uptime
            except (TypeError, ValueError):
                errors += 1
    print(f"Rows: {total} | Invalid: {errors} | Uptime gaps >3s: {gaps}")
    return 1 if errors or not total else 0

if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: python scripts/check_csv.py FILE.csv", file=sys.stderr)
        sys.exit(2)
    try:
        sys.exit(check(sys.argv[1]))
    except (OSError, ValueError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        sys.exit(2)
