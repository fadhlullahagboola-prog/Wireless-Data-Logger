# Example data

`sample_log.csv` is **synthetic demonstration data**, not a real sensor capture. Replace or supplement it with an actual CSV collected from the ESP32, and document the test conditions.
