#include <Arduino.h>
#include <DHT.h>
#include <SPI.h>
#include <SD.h>
#include <WiFi.h>
#include <WebServer.h>
#include <time.h>
#include <math.h>
#include "config.h"
#if ENABLE_WIFI
#include "secrets.h"
#endif

DHT dht(DHT_PIN, DHT_TYPE);
SPIClass sdSpi(VSPI);
WebServer server(80);
bool sdReady = false;
bool wifiReady = false;
bool haveReading = false;
float latestTemp = NAN;
float latestHumidity = NAN;
uint32_t successfulSamples = 0;
uint32_t sensorErrors = 0;
uint32_t storageErrors = 0;
unsigned long lastSampleAt = 0;

String timestampUTC() {
  struct tm tmNow;
  if (getLocalTime(&tmNow, 10) && tmNow.tm_year >= 125) {
    char buf[25];
    strftime(buf, sizeof(buf), "%Y-%m-%dT%H:%M:%SZ", &tmNow);
    return String(buf);
  }
  return ""; // No valid wall clock available; uptime is logged separately.
}

bool initializeSD() {
  sdSpi.begin(SD_SCK_PIN, SD_MISO_PIN, SD_MOSI_PIN, SD_CS_PIN);
  if (!SD.begin(SD_CS_PIN, sdSpi)) return false;
  if (SD.cardType() == CARD_NONE) return false;
  return true;
}

bool appendCSV(const String& line) {
  if (!sdReady) return false;
  bool needsHeader = !SD.exists(LOG_PATH);
  File file = SD.open(LOG_PATH, FILE_APPEND);
  if (!file) return false;
  bool ok = true;
  if (needsHeader) ok = file.println("timestamp_utc,uptime_ms,temperature_c,humidity_pct") > 0;
  if (ok) ok = file.println(line) > 0;
  file.flush();
  file.close();
  return ok;
}

void sampleAndLog() {
  float humidity = dht.readHumidity();
  float temperature = dht.readTemperature();
  if (isnan(humidity) || isnan(temperature)) {
    ++sensorErrors;
    Serial.println("ERROR: DHT11 read failed");
    return;
  }
  latestTemp = temperature;
  latestHumidity = humidity;
  haveReading = true;
  String line = timestampUTC() + "," + String(millis()) + "," +
                String(temperature, 1) + "," + String(humidity, 1);
  Serial.println("Sample: " + line);
  if (appendCSV(line)) {
    ++successfulSamples;
    Serial.println("CSV append OK");
  } else {
    ++storageErrors;
    Serial.println("ERROR: CSV append failed; check SD configuration/card");
  }
}

String jsonStatus() {
  String s = "{\"temperature_c\":";
  s += haveReading ? String(latestTemp, 1) : "null";
  s += ",\"humidity_pct\":";
  s += haveReading ? String(latestHumidity, 1) : "null";
  s += ",\"timestamp_utc\":\"" + timestampUTC() + "\"";
  s += ",\"uptime_ms\":" + String(millis());
  s += ",\"successful_samples\":" + String(successfulSamples);
  s += ",\"sensor_errors\":" + String(sensorErrors);
  s += ",\"storage_errors\":" + String(storageErrors);
  s += ",\"sd_ready\":" + String(sdReady ? "true" : "false");
  s += "}";
  return s;
}

void configureWebServer() {
  server.on("/", HTTP_GET, []() {
    server.send(200, "text/html", R"HTML(<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>ESP32 Environmental Logger</title><style>body{font-family:system-ui;background:#101827;color:#eaf0f8;max-width:800px;margin:50px auto;padding:20px}header{border-bottom:1px solid #40506b;padding-bottom:20px}main{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:18px;margin-top:24px}.tile{background:#1b2940;border:1px solid #33435d;border-radius:14px;padding:24px}.value{font-size:2.4rem;font-weight:700}small{color:#aebed2}a{color:#9fd3ff}</style></head><body><header><h1>ESP32 Environmental Logger</h1><p>Live environmental telemetry · <a href="/api/status">JSON API</a> · <a href="/download">Download CSV</a></p></header><main><section class="tile"><small>Temperature</small><div class="value" id="temp">--</div></section><section class="tile"><small>Humidity</small><div class="value" id="humidity">--</div></section><section class="tile"><small>Stored samples (this boot)</small><div class="value" id="count">--</div></section><section class="tile"><small>Storage status</small><div class="value" id="storage">--</div></section></main><p id="meta"></p><script>async function refresh(){try{const r=await fetch('/api/status');const d=await r.json();document.getElementById('temp').textContent=d.temperature_c===null?'--':d.temperature_c+' °C';document.getElementById('humidity').textContent=d.humidity_pct===null?'--':d.humidity_pct+' %';document.getElementById('count').textContent=d.successful_samples;document.getElementById('storage').textContent=d.sd_ready?'Ready':'Unavailable';document.getElementById('meta').textContent='UTC: '+(d.timestamp_utc||'not synchronized')+' | Sensor errors: '+d.sensor_errors+' | Storage errors: '+d.storage_errors;}catch(e){document.getElementById('meta').textContent='ESP32 unreachable';}}refresh();setInterval(refresh,3000);</script></body></html>)HTML");
  });
  server.on("/api/status", HTTP_GET, []() { server.send(200, "application/json", jsonStatus()); });
  server.on("/download", HTTP_GET, []() {
    if (!sdReady || !SD.exists(LOG_PATH)) { server.send(404, "text/plain", "No CSV file available"); return; }
    File f = SD.open(LOG_PATH, FILE_READ);
    if (!f) { server.send(500, "text/plain", "Could not open CSV"); return; }
    server.sendHeader("Content-Disposition", "attachment; filename=environment.csv");
    server.streamFile(f, "text/csv");
    f.close();
  });
  server.begin();
}

void setup() {
  Serial.begin(SERIAL_BAUD);
  delay(1000);
  Serial.println("ESP32 Environmental Logger starting");
  dht.begin();
  sdReady = initializeSD();
  Serial.println(sdReady ? "SD ready" : "SD unavailable: verify card format and board pin mapping");
#if ENABLE_WIFI
  WiFi.mode(WIFI_STA);
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
  unsigned long start = millis();
  while (WiFi.status() != WL_CONNECTED && millis() - start < WIFI_CONNECT_TIMEOUT_MS) delay(200);
  wifiReady = WiFi.status() == WL_CONNECTED;
  if (wifiReady) {
    Serial.print("Dashboard: http://"); Serial.println(WiFi.localIP());
#if ENABLE_NTP
    configTime(UTC_OFFSET_SECONDS, 0, "pool.ntp.org", "time.google.com");
#endif
#if !ENABLE_DEEP_SLEEP
    configureWebServer();
#endif
  } else Serial.println("Wi-Fi unavailable; offline logging continues");
#endif
  // DHT11 needs adequate settling time after power-up.
  delay(2000);
  sampleAndLog();
  lastSampleAt = millis();
#if ENABLE_DEEP_SLEEP
  Serial.flush();
  esp_sleep_enable_timer_wakeup((uint64_t)DEEP_SLEEP_SECONDS * 1000000ULL);
  esp_deep_sleep_start();
#endif
}

void loop() {
#if ENABLE_WIFI && !ENABLE_DEEP_SLEEP
  if (wifiReady) server.handleClient();
#endif
  unsigned long now = millis();
  if (now - lastSampleAt >= SAMPLE_INTERVAL_MS) {
    lastSampleAt = now;
    sampleAndLog();
  }
  delay(5);
}
