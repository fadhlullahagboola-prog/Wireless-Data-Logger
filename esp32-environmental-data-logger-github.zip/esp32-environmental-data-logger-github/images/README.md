# Project images

Add your own hardware photo (`prototype.jpg`), serial output (`serial-monitor.png`), and dashboard screenshot (`dashboard.png`). Only use photographs and screenshots from your actual setup.
