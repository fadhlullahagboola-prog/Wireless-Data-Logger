# Development notes

Firmware changes should include: the board used, the hardware revision, test steps, and observed serial output. Keep configuration changes in `config.h` and never commit `secrets.h`. Update the validation table only after collecting evidence.
