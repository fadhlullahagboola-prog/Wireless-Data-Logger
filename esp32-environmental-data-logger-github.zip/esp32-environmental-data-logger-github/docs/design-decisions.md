# Engineering decisions

**DHT11 over a higher-precision sensor:** It was already available, making it useful for demonstrating integration and debugging. It is not a precision measurement instrument.

**CSV over binary logging:** CSV can be inspected without custom tools. It has higher storage overhead and less predictable write timing than a binary format.

**Flush after every record:** Prioritizes persistence and ease of testing. May increase write amplification and energy use. For battery optimization, consider buffered writes and controlled shutdown.

**NTP timestamps with uptime fallback:** Real-world UTC is only available after network synchronization; blank UTC fields explicitly indicate lack of time synchronization. `millis()` measures time since boot only.

**Wi-Fi and deep sleep as separate operating modes:** Keeping an always-on HTTP server conflicts with deep sleep. The deep-sleep build logs once per wake and then returns to sleep.

**Board-specific storage interface:** ESP32 supports multiple SD interfaces. Pin routing is determined by the actual SunFounder extension board, not a generic ESP32 pinout image.
