# Hardware interface

## Components

- ESP32 development board and SunFounder extension board with microSD slot
- DHT11 four-pin temperature and humidity sensor
- 10 kΩ DATA pull-up resistor
- microSD card

## DHT11 wiring

| DHT11 terminal | Connection |
|---|---|
| VCC | 3.3 V |
| DATA | ESP32 GPIO 4 |
| NC | Unconnected |
| GND | Ground |
| Pull-up | 10 kΩ from DATA to 3.3 V |

Orient the bare DHT11 with its front grille facing you and pins downward to read the terminals from left to right: VCC, DATA, NC, GND.

## SD interface

The SD driver and pin mapping are configured in `firmware/EnvironmentalLogger/config.h`. The included SPI settings are generic ESP32 defaults; SunFounder extension board revisions may use different routing. Use the configuration appropriate for the installed board.

## Hardware debugging

The DHT11 uses a single-wire digital interface with a pull-up resistor. Reliable breadboard contact is essential. Arduino IDE uses normal USB upload for this project; hardware JTAG debugging requires separate compatible equipment.
