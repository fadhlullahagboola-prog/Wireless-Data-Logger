# Hardware connections

The DHT11 is a bare four-pin sensor. With its vented face toward you and leads pointing downward, the pins from left to right are **VCC, DATA, NC, GND**.

| DHT11 pin | ESP32 connection |
|---|---|
| 1 VCC | 3.3 V |
| 2 DATA | GPIO 4 |
| 3 NC | Unconnected |
| 4 GND | GND |

Use a **10 kΩ pull-up resistor between VCC and DATA**. The SunFounder extension board's built-in microSD slot is used for storage. The board-specific SD pin routing has not been established from the information available; the firmware's `SD_*_PIN` values are standard ESP32 VSPI defaults and must match the actual board before use.

## Logical system diagram

```mermaid
flowchart LR
  D[DHT11 sensor] -->|Single-wire data GPIO4| E[ESP32]
  E -->|SPI, board-specific wiring| S[microSD slot]
  E -->|Wi-Fi| W[Web dashboard and JSON API]
  N[NTP time server] -->|Wi-Fi| E
  P[USB 5 V / extension board regulator] --> E
```

The diagram is a logical architecture, not a verified SunFounder PCB schematic.
