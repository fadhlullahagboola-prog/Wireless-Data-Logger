# Media to add

Replace these placeholders with **your own** evidence:

- `hardware-setup.jpg`: clear photo of actual wiring and ESP32 board
- `serial-output.png`: successful startup and SD append log
- `dashboard.png`: real Wi-Fi dashboard running on the ESP32
- `temperature-humidity-plot.png`: plot from real CSV capture
- `pcb-layout.png`: only after a custom PCB has actually been designed

Do not upload Wi-Fi credentials, location-sensitive data, or serial numbers.
