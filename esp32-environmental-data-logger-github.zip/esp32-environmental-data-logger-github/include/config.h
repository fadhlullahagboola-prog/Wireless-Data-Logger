#pragma once
// Adjust these values to match your specific ESP32 and SunFounder board.
#define DHT_PIN 4
#define DHT_TYPE DHT11
#define SAMPLE_INTERVAL_MS 2000UL
#define SERIAL_BAUD 115200
#define LOG_PATH "/environment.csv"
// Standard ESP32 VSPI pins are defaults, NOT verified for SunFounder SD slot.
#define SD_CS_PIN 5
#define SD_SCK_PIN 18
#define SD_MISO_PIN 19
#define SD_MOSI_PIN 23
// Disable Wi-Fi if you want an offline logger.
#define ENABLE_WIFI 1
#define ENABLE_NTP 1
// Set 1 to enter deep sleep after each successful logging cycle.
// Deep sleep disables the live dashboard and restarts the ESP32 on wake.
#define ENABLE_DEEP_SLEEP 0
#define DEEP_SLEEP_SECONDS 60
#define WIFI_CONNECT_TIMEOUT_MS 12000UL
#define UTC_OFFSET_SECONDS 0
